<div id="inner">
  <aside>
    <nav><span>pre-installation</span> <span class="active"> license </span> <span> configuration</span><span>completed</span></nav>
  </aside>
  <div class="middle"></div>
  <main>
    <h3>License Agreement</h3>
    <div class="divider"></div>
    <iframe src="license.php" class="license"></iframe>
  </main>
</div>
<footer class="clearfix"> <small>current <b>car dealer pro v.3.0</b></small>
  <div id="buttons">
    <button type="button" class="button" onclick="document.location.href='setup.php';" name="back">Back</button>
    &nbsp;&nbsp;
    <button type="button" class="button" onclick="document.location.href='setup.php?step=2';" name="next" tabindex="3" >Next</button>
  </div>
</footer>