<div class="wojo fof card">
  <div class="content">
    <h1><?php echo Lang::$word->META_ERROR;?></h1>
    <p><?php echo Lang::$word->META_ERROR1;?> :(</p>
    <p><?php echo Lang::$word->META_ERROR2;?></p>
  </div>
</div>